# -------------------------------------------------------------------------------------------------
#  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
#  https://nautechsystems.io
#
#  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
#  You may not use this file except in compliance with the License.
#  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
# -------------------------------------------------------------------------------------------------
"""
Integration adapter for the Ondo Perps venue.

`ONDO` here is the Ondo Perps exchange venue, not the `ONDO` crypto asset ticker.
"""

from nautilus_trader._fixup import fixup_module_names
from nautilus_trader._libnautilus.ondo import *  # noqa: F403 (undefined-local-with-import-star)


__all__ = [
    "ONDO",
    "ONDO_CLIENT_ID",
    "ONDO_VENUE",
    "OndoContinuousExecutionConfig",
    "OndoDataClientConfig",
    "OndoDataClientFactory",
    "OndoEnvironment",
    "OndoExecutionClientConfig",
    "OndoExecutionClientFactory",
    "OndoExecutionEnvelopeConfig",
]

fixup_module_names(globals(), __name__)
del fixup_module_names
